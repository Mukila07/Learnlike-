const input = document.getElementById("todo-input");
const addBtn = document.getElementById("add-btn");
const todoList = document.getElementById("todo-list");

addBtn.addEventListener("click", addTask);

function addTask() {
    const value = input.value.trim();
    if (value === "") return;

    createTaskElement(value);
    input.value = "";
}

// CREATE + READ
function createTaskElement(text) {
    const li = document.createElement("li");
    li.classList.add("todo-item");

    li.innerHTML = `
        <span class="task-text">${text}</span>
        <div class="actions">
            <button class="edit-btn">Edit</button>
            <button class="delete-btn">Delete</button>
        </div>
    `;

    // DELETE
    li.querySelector(".delete-btn").addEventListener("click", () => {
        li.remove();
    });

    // UPDATE
    li.querySelector(".edit-btn").addEventListener("click", () => {
        editTask(li);
    });

    todoList.appendChild(li);
}

// UPDATE function
function editTask(li) {
    const textSpan = li.querySelector(".task-text");
    const oldText = textSpan.textContent;

    li.innerHTML = `
        <input class="edit-input" type="text" value="${oldText}">
        <div class="actions">
            <button class="save-btn">Save</button>
            <button class="cancel-btn">Cancel</button>
        </div>
    `;

    li.querySelector(".save-btn").addEventListener("click", () => {
        const newValue = li.querySelector(".edit-input").value.trim();
        if (newValue === "") return;

        textSpan.textContent = newValue;
        li.innerHTML = `
            <span class="task-text">${newValue}</span>
            <div class="actions">
                <button class="edit-btn">Edit</button>
                <button class="delete-btn">Delete</button>
            </div>
        `;

        li.querySelector(".edit-btn").addEventListener("click", () => editTask(li));
        li.querySelector(".delete-btn").addEventListener("click", () => li.remove());
    });

    li.querySelector(".cancel-btn").addEventListener("click", () => {
        li.innerHTML = `
            <span class="task-text">${oldText}</span>
            <div class="actions">
                <button class="edit-btn">Edit</button>
                <button class="delete-btn">Delete</button>
            </div>
        `;

        li.querySelector(".edit-btn").addEventListener("click", () => editTask(li));
        li.querySelector(".delete-btn").addEventListener("click", () => li.remove());
    });
}
